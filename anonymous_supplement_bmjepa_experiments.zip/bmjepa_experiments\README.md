﻿# Anonymous Supplement: BM-JEPA Experiment Suite

This archive contains anonymized code, configurations, result CSVs, tests, and
plotting scripts for the experimental results in the submitted paper.

## Contents

- `configs/`: YAML configuration files for all reported experiments.
- `data/`: linear-Gaussian synthetic data generator.
- `models/`: OLS, reduced-rank regression, and linear BM-JEPA helpers.
- `metrics/`: subspace and rank metrics.
- `experiments/`: experiment entry points.
- `plots/`: plotting scripts for paper figures.
- `results/`: CSV outputs used by the plotting scripts.
- `figures/`: PDF figures generated from the CSV outputs.
- `tests/`: unit tests for generator, estimators, metrics, and schema checks.
- `paper/`: experiment-section TeX snippets used for the paper and appendix.

## Environment

The code was tested with Python 3.11. Install dependencies with:

```bash
python -m pip install -r requirements.txt
```

The MNIST CNN experiment uses PyTorch and torchvision. It runs on CPU, but the
reported large MNIST diagnostic was run with CUDA when available.

## Reproducing Results

Run the synthetic suite and the small real-image diagnostic:

```bash
python -m experiments.run_all
python -m plots.plot_main
```

Run the MNIST CNN diagnostic:

```bash
python -m experiments.exp_regularizer_mnist_gpu
python -m plots.plot_regularizer_mnist_gpu
python -m plots.plot_regularizer_mnist_gpu_samples
```

Run the unit tests:

```bash
pytest -q
```

## Data

Synthetic experiments generate data from the included linear-Gaussian generator.
The small digit experiment uses `sklearn.datasets.load_digits`. The MNIST
diagnostic uses torchvision's MNIST loader and downloads the public MNIST data
if it is not already available locally.

## Anonymization

This archive removes version-control metadata, local logs, cached bytecode,
draft PDFs, personal paths, and identifying files. The code is provided only for
anonymous review and reproducibility.
